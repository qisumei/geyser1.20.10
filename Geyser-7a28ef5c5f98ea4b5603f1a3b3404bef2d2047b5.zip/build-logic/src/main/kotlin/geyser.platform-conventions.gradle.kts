plugins {
    application
    id("geyser.publish-conventions")
}